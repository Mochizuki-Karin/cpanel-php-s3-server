<?php
/**
 * Router for handling S3 API requests
 */
class Router
{
    private $response;
    private $auth;
    private $bucketManager;
    private $objectManager;
    
    public function __construct($response, $auth, $bucketManager, $objectManager)
    {
        $this->response = $response;
        $this->auth = $auth;
        $this->bucketManager = $bucketManager;
        $this->objectManager = $objectManager;
    }
    
    /**
     * Handle incoming HTTP request
     */
    public function handleRequest()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = $this->parseUri();
        
        Utils::logInfo("Request: {$method} {$uri['path']}");
        
        // Authenticate request (skip for OPTIONS)
        if ($method !== 'OPTIONS' && !$this->auth->authenticate()) {
            $this->response->sendError(403, 'AccessDenied', 'Access Denied');
            return;
        }
        
        // Route the request
        try {
            $this->routeRequest($method, $uri);
        } catch (Exception $e) {
            Utils::logError('Routing error: ' . $e->getMessage());
            $this->response->sendError(500, 'InternalError', 'Internal server error');
        }
    }
    
    /**
     * Parse request URI
     */
    private function parseUri()
    {
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        
        // Remove script name from path if present
        $scriptName = $_SERVER['SCRIPT_NAME'];
        if (strpos($path, $scriptName) === 0) {
            $path = substr($path, strlen($scriptName));
        }
        
        // Remove leading slash
        $path = ltrim($path, '/');
        
        // Parse path components
        $parts = $path ? explode('/', $path) : [];
        
        return [
            'path' => $path,
            'parts' => $parts,
            'bucket' => isset($parts[0]) && $parts[0] !== '' ? $parts[0] : null,
            'key' => isset($parts[1]) ? implode('/', array_slice($parts, 1)) : null,
            'query' => $_GET
        ];
    }
    
    /**
     * Route request to appropriate handler
     */
    private function routeRequest($method, $uri)
    {
        $bucket = $uri['bucket'];
        $key = $uri['key'];
        
        // Root level operations (service level)
        if (!$bucket) {
            switch ($method) {
                case 'GET':
                    $this->listBuckets();
                    break;
                default:
                    $this->response->sendError(405, 'MethodNotAllowed', 'Method not allowed');
            }
            return;
        }
        
        // Bucket level operations
        if (!$key) {
            switch ($method) {
                case 'GET':
                    $this->listObjects($bucket, $uri['query']);
                    break;
                case 'PUT':
                    $this->createBucket($bucket);
                    break;
                case 'DELETE':
                    $this->deleteBucket($bucket);
                    break;
                case 'HEAD':
                    $this->headBucket($bucket);
                    break;
                default:
                    $this->response->sendError(405, 'MethodNotAllowed', 'Method not allowed');
            }
            return;
        }
        
        // Object level operations
        switch ($method) {
            case 'GET':
                $this->getObject($bucket, $key);
                break;
            case 'PUT':
                $this->putObject($bucket, $key);
                break;
            case 'DELETE':
                $this->deleteObject($bucket, $key);
                break;
            case 'HEAD':
                $this->headObject($bucket, $key);
                break;
            default:
                $this->response->sendError(405, 'MethodNotAllowed', 'Method not allowed');
        }
    }
    
    /**
     * List all buckets
     */
    private function listBuckets()
    {
        $buckets = $this->bucketManager->listBuckets();
        $this->response->sendBucketList($buckets);
    }
    
    /**
     * Create a new bucket
     */
    private function createBucket($bucketName)
    {
        if (!Utils::isValidBucketName($bucketName)) {
            $this->response->sendError(400, 'InvalidBucketName', 'The specified bucket is not valid.');
            return;
        }
        
        if ($this->bucketManager->bucketExists($bucketName)) {
            $this->response->sendError(409, 'BucketAlreadyExists', 'The requested bucket name is not available.');
            return;
        }
        
        if ($this->bucketManager->createBucket($bucketName)) {
            $this->response->sendSuccess(null, 200);
        } else {
            $this->response->sendError(500, 'InternalError', 'Failed to create bucket');
        }
    }
    
    /**
     * Delete a bucket
     */
    private function deleteBucket($bucketName)
    {
        if (!$this->bucketManager->bucketExists($bucketName)) {
            $this->response->sendError(404, 'NoSuchBucket', 'The specified bucket does not exist.');
            return;
        }
        
        // Check if bucket is empty
        $objects = $this->objectManager->listObjects($bucketName);
        if (!empty($objects)) {
            $this->response->sendError(409, 'BucketNotEmpty', 'The bucket you tried to delete is not empty.');
            return;
        }
        
        if ($this->bucketManager->deleteBucket($bucketName)) {
            $this->response->sendSuccess(null, 204);
        } else {
            $this->response->sendError(500, 'InternalError', 'Failed to delete bucket');
        }
    }
    
    /**
     * Check if bucket exists (HEAD request)
     */
    private function headBucket($bucketName)
    {
        if ($this->bucketManager->bucketExists($bucketName)) {
            $this->response->sendSuccess(null, 200);
        } else {
            $this->response->sendError(404, 'NoSuchBucket', 'The specified bucket does not exist.');
        }
    }
    
    /**
     * List objects in a bucket
     */
    private function listObjects($bucketName, $query)
    {
        if (!$this->bucketManager->bucketExists($bucketName)) {
            $this->response->sendError(404, 'NoSuchBucket', 'The specified bucket does not exist.');
            return;
        }
        
        $prefix = isset($query['prefix']) ? $query['prefix'] : '';
        $marker = isset($query['marker']) ? $query['marker'] : '';
        $maxKeys = isset($query['max-keys']) ? intval($query['max-keys']) : 1000;
        
        $objects = $this->objectManager->listObjects($bucketName, $prefix, $marker, $maxKeys);
        $this->response->sendObjectList($bucketName, $objects, $prefix, $marker, $maxKeys);
    }
    
    /**
     * Upload/Put an object
     */
    private function putObject($bucketName, $key)
    {
        if (!$this->bucketManager->bucketExists($bucketName)) {
            $this->response->sendError(404, 'NoSuchBucket', 'The specified bucket does not exist.');
            return;
        }
        
        if (!Utils::isValidObjectKey($key)) {
            $this->response->sendError(400, 'InvalidKey', 'The specified key is not valid.');
            return;
        }
        
        // Get request body
        $input = fopen('php://input', 'r');
        
        $result = $this->objectManager->putObject($bucketName, $key, $input);
        
        if ($result) {
            $this->response->sendSuccess(null, 200);
        } else {
            $this->response->sendError(500, 'InternalError', 'Failed to store object');
        }
    }
    
    /**
     * Get/Download an object
     */
    private function getObject($bucketName, $key)
    {
        if (!$this->bucketManager->bucketExists($bucketName)) {
            $this->response->sendError(404, 'NoSuchBucket', 'The specified bucket does not exist.');
            return;
        }
        
        $filePath = $this->objectManager->getObjectPath($bucketName, $key);
        
        if (!file_exists($filePath)) {
            $this->response->sendError(404, 'NoSuchKey', 'The specified key does not exist.');
            return;
        }
        
        // Handle range requests
        $range = null;
        if (isset($_SERVER['HTTP_RANGE'])) {
            $fileSize = filesize($filePath);
            $range = Utils::parseRangeHeader($_SERVER['HTTP_RANGE'], $fileSize);
            
            if ($range === false) {
                $this->response->sendError(416, 'InvalidRange', 'The requested range is not satisfiable');
                return;
            }
        }
        
        $this->response->sendFile($filePath, basename($key), $range);
    }
    
    /**
     * Delete an object
     */
    private function deleteObject($bucketName, $key)
    {
        if (!$this->bucketManager->bucketExists($bucketName)) {
            $this->response->sendError(404, 'NoSuchBucket', 'The specified bucket does not exist.');
            return;
        }
        
        if ($this->objectManager->deleteObject($bucketName, $key)) {
            $this->response->sendSuccess(null, 204);
        } else {
            // S3 returns success even if object doesn't exist
            $this->response->sendSuccess(null, 204);
        }
    }
    
    /**
     * Get object metadata (HEAD request)
     */
    private function headObject($bucketName, $key)
    {
        if (!$this->bucketManager->bucketExists($bucketName)) {
            $this->response->sendError(404, 'NoSuchBucket', 'The specified bucket does not exist.');
            return;
        }
        
        $metadata = $this->objectManager->getObjectMetadata($bucketName, $key);
        
        if ($metadata) {
            $this->response->sendObjectMetadata($metadata);
        } else {
            $this->response->sendError(404, 'NoSuchKey', 'The specified key does not exist.');
        }
    }
}

