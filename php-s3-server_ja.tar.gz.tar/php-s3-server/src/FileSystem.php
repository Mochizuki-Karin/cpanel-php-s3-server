<?php
/**
 * File system abstraction layer for secure file operations
 */
class FileSystem
{
    private $storagePath;
    private $bucketsPath;
    
    public function __construct($storagePath)
    {
        $this->storagePath = rtrim($storagePath, '/');
        $this->bucketsPath = $this->storagePath . '/buckets';
        
        // Ensure storage directory exists
        $this->ensureDirectory($this->storagePath);
        $this->ensureDirectory($this->bucketsPath);
    }
    
    /**
     * Get the full path for a bucket
     */
    public function getBucketPath($bucketName)
    {
        $bucketName = Utils::sanitizePath($bucketName);
        return $this->bucketsPath . '/' . $bucketName;
    }
    
    /**
     * Get the full path for an object
     */
    public function getObjectPath($bucketName, $objectKey)
    {
        $bucketName = Utils::sanitizePath($bucketName);
        $objectKey = Utils::sanitizePath($objectKey);
        return $this->bucketsPath . '/' . $bucketName . '/' . $objectKey;
    }
    
    /**
     * Get the metadata file path for an object
     */
    public function getMetadataPath($bucketName, $objectKey)
    {
        return $this->getObjectPath($bucketName, $objectKey) . '.meta';
    }
    
    /**
     * Check if a bucket directory exists
     */
    public function bucketExists($bucketName)
    {
        $bucketPath = $this->getBucketPath($bucketName);
        return is_dir($bucketPath);
    }
    
    /**
     * Create a bucket directory
     */
    public function createBucket($bucketName)
    {
        $bucketPath = $this->getBucketPath($bucketName);
        
        if ($this->bucketExists($bucketName)) {
            return false; // Already exists
        }
        
        return $this->ensureDirectory($bucketPath);
    }
    
    /**
     * Delete a bucket directory (only if empty)
     */
    public function deleteBucket($bucketName)
    {
        $bucketPath = $this->getBucketPath($bucketName);
        
        if (!$this->bucketExists($bucketName)) {
            return false;
        }
        
        // Check if bucket is empty
        $files = $this->listBucketContents($bucketName);
        if (!empty($files)) {
            return false; // Not empty
        }
        
        return rmdir($bucketPath);
    }
    
    /**
     * List all buckets
     */
    public function listBuckets()
    {
        $buckets = [];
        
        if (!is_dir($this->bucketsPath)) {
            return $buckets;
        }
        
        $handle = opendir($this->bucketsPath);
        if ($handle) {
            while (($entry = readdir($handle)) !== false) {
                if ($entry !== '.' && $entry !== '..' && is_dir($this->bucketsPath . '/' . $entry)) {
                    $buckets[] = [
                        'name' => $entry,
                        'created' => date('c', filemtime($this->bucketsPath . '/' . $entry))
                    ];
                }
            }
            closedir($handle);
        }
        
        // Sort by name
        usort($buckets, function($a, $b) {
            return strcmp($a['name'], $b['name']);
        });
        
        return $buckets;
    }
    
    /**
     * List contents of a bucket
     */
    public function listBucketContents($bucketName, $prefix = '', $maxKeys = 1000)
    {
        $bucketPath = $this->getBucketPath($bucketName);
        $objects = [];
        
        if (!$this->bucketExists($bucketName)) {
            return $objects;
        }
        
        $this->scanDirectory($bucketPath, $bucketPath, $objects, $prefix, $maxKeys);
        
        // Sort by key
        usort($objects, function($a, $b) {
            return strcmp($a['key'], $b['key']);
        });
        
        return array_slice($objects, 0, $maxKeys);
    }
    
    /**
     * Recursively scan directory for objects
     */
    private function scanDirectory($currentPath, $basePath, &$objects, $prefix = '', $maxKeys = 1000)
    {
        if (count($objects) >= $maxKeys) {
            return;
        }
        
        $handle = opendir($currentPath);
        if (!$handle) {
            return;
        }
        
        while (($entry = readdir($handle)) !== false && count($objects) < $maxKeys) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            
            $fullPath = $currentPath . '/' . $entry;
            $relativePath = substr($fullPath, strlen($basePath) + 1);
            
            // Skip metadata files
            if (substr($entry, -5) === '.meta') {
                continue;
            }
            
            if (is_file($fullPath)) {
                // Check prefix filter
                if ($prefix && strpos($relativePath, $prefix) !== 0) {
                    continue;
                }
                
                $objects[] = [
                    'key' => $relativePath,
                    'size' => filesize($fullPath),
                    'modified' => date('c', filemtime($fullPath)),
                    'etag' => Utils::calculateETag($fullPath),
                    'path' => $fullPath
                ];
            } elseif (is_dir($fullPath)) {
                // Recursively scan subdirectories
                $this->scanDirectory($fullPath, $basePath, $objects, $prefix, $maxKeys);
            }
        }
        
        closedir($handle);
    }
    
    /**
     * Check if an object exists
     */
    public function objectExists($bucketName, $objectKey)
    {
        $objectPath = $this->getObjectPath($bucketName, $objectKey);
        return file_exists($objectPath) && is_file($objectPath);
    }
    
    /**
     * Store an object from input stream
     */
    public function storeObject($bucketName, $objectKey, $inputStream, $metadata = [])
    {
        $objectPath = $this->getObjectPath($bucketName, $objectKey);
        $metadataPath = $this->getMetadataPath($bucketName, $objectKey);
        
        // Ensure parent directory exists
        $parentDir = dirname($objectPath);
        if (!$this->ensureDirectory($parentDir)) {
            return false;
        }
        
        // Create temporary file first
        $tempPath = $objectPath . '.tmp';
        $tempFile = fopen($tempPath, 'wb');
        
        if (!$tempFile) {
            Utils::logError("Failed to create temporary file: {$tempPath}");
            return false;
        }
        
        // Copy from input stream to temporary file
        $bytesWritten = 0;
        while (!feof($inputStream)) {
            $chunk = fread($inputStream, 8192);
            if ($chunk === false) {
                break;
            }
            
            $written = fwrite($tempFile, $chunk);
            if ($written === false) {
                fclose($tempFile);
                unlink($tempPath);
                Utils::logError("Failed to write to temporary file: {$tempPath}");
                return false;
            }
            
            $bytesWritten += $written;
        }
        
        fclose($tempFile);
        
        // Move temporary file to final location
        if (!rename($tempPath, $objectPath)) {
            unlink($tempPath);
            Utils::logError("Failed to move temporary file to final location: {$objectPath}");
            return false;
        }
        
        // Store metadata
        $objectMetadata = array_merge([
            'Content-Type' => Utils::getMimeType($objectKey),
            'Content-Length' => $bytesWritten,
            'Last-Modified' => gmdate('D, d M Y H:i:s T'),
            'ETag' => Utils::calculateETag($objectPath),
            'x-amz-storage-class' => 'STANDARD'
        ], $metadata);
        
        $this->storeMetadata($bucketName, $objectKey, $objectMetadata);
        
        Utils::logInfo("Stored object: {$bucketName}/{$objectKey} ({$bytesWritten} bytes)");
        return true;
    }
    
    /**
     * Delete an object
     */
    public function deleteObject($bucketName, $objectKey)
    {
        $objectPath = $this->getObjectPath($bucketName, $objectKey);
        $metadataPath = $this->getMetadataPath($bucketName, $objectKey);
        
        $deleted = false;
        
        // Delete object file
        if (file_exists($objectPath)) {
            $deleted = unlink($objectPath);
        }
        
        // Delete metadata file
        if (file_exists($metadataPath)) {
            unlink($metadataPath);
        }
        
        // Clean up empty parent directories
        $this->cleanupEmptyDirectories(dirname($objectPath), $this->getBucketPath($bucketName));
        
        if ($deleted) {
            Utils::logInfo("Deleted object: {$bucketName}/{$objectKey}");
        }
        
        return $deleted;
    }
    
    /**
     * Get object metadata
     */
    public function getObjectMetadata($bucketName, $objectKey)
    {
        $objectPath = $this->getObjectPath($bucketName, $objectKey);
        $metadataPath = $this->getMetadataPath($bucketName, $objectKey);
        
        if (!file_exists($objectPath)) {
            return null;
        }
        
        // Load stored metadata
        $metadata = [];
        if (file_exists($metadataPath)) {
            $metadataContent = file_get_contents($metadataPath);
            if ($metadataContent) {
                $metadata = json_decode($metadataContent, true) ?: [];
            }
        }
        
        // Add/update basic metadata
        $metadata['Content-Length'] = filesize($objectPath);
        $metadata['Last-Modified'] = gmdate('D, d M Y H:i:s T', filemtime($objectPath));
        $metadata['ETag'] = Utils::calculateETag($objectPath);
        
        if (!isset($metadata['Content-Type'])) {
            $metadata['Content-Type'] = Utils::getMimeType($objectKey);
        }
        
        return $metadata;
    }
    
    /**
     * Store object metadata
     */
    private function storeMetadata($bucketName, $objectKey, $metadata)
    {
        $metadataPath = $this->getMetadataPath($bucketName, $objectKey);
        $metadataJson = json_encode($metadata, JSON_PRETTY_PRINT);
        
        return file_put_contents($metadataPath, $metadataJson, LOCK_EX) !== false;
    }
    
    /**
     * Ensure directory exists
     */
    private function ensureDirectory($path)
    {
        if (is_dir($path)) {
            return true;
        }
        
        return mkdir($path, 0755, true);
    }
    
    /**
     * Clean up empty parent directories
     */
    private function cleanupEmptyDirectories($path, $stopAt)
    {
        if ($path === $stopAt || !is_dir($path)) {
            return;
        }
        
        // Check if directory is empty
        $files = scandir($path);
        $isEmpty = count($files) <= 2; // Only . and .. entries
        
        if ($isEmpty) {
            rmdir($path);
            // Recursively clean parent
            $this->cleanupEmptyDirectories(dirname($path), $stopAt);
        }
    }
    
    /**
     * Get disk usage for a bucket
     */
    public function getBucketSize($bucketName)
    {
        $bucketPath = $this->getBucketPath($bucketName);
        
        if (!$this->bucketExists($bucketName)) {
            return 0;
        }
        
        return $this->getDirectorySize($bucketPath);
    }
    
    /**
     * Calculate directory size recursively
     */
    private function getDirectorySize($path)
    {
        $size = 0;
        
        $handle = opendir($path);
        if (!$handle) {
            return 0;
        }
        
        while (($entry = readdir($handle)) !== false) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            
            $fullPath = $path . '/' . $entry;
            
            if (is_file($fullPath)) {
                $size += filesize($fullPath);
            } elseif (is_dir($fullPath)) {
                $size += $this->getDirectorySize($fullPath);
            }
        }
        
        closedir($handle);
        return $size;
    }
}

