<?php
/**
 * Authentication and security handler for S3 API compatibility
 */
class Auth
{
    private $config;
    private $credentials;
    
    public function __construct($config)
    {
        $this->config = $config;
        $this->loadCredentials();
    }
    
    /**
     * Authenticate incoming request
     */
    public function authenticate()
    {
        // Skip authentication for public endpoints if configured
        if (isset($this->config['public_access']) && $this->config['public_access']) {
            return true;
        }
        
        // Try different authentication methods
        if ($this->authenticateWithSignature()) {
            return true;
        }
        
        if ($this->authenticateWithApiKey()) {
            return true;
        }
        
        if ($this->authenticateWithBasicAuth()) {
            return true;
        }
        
        Utils::logError('Authentication failed for request: ' . $_SERVER['REQUEST_URI']);
        return false;
    }
    
    /**
     * Authenticate using AWS Signature Version 4 (simplified)
     */
    private function authenticateWithSignature()
    {
        $authHeader = $this->getAuthorizationHeader();
        
        if (!$authHeader || strpos($authHeader, 'AWS4-HMAC-SHA256') !== 0) {
            return false;
        }
        
        // Parse authorization header
        $authParts = $this->parseAuthorizationHeader($authHeader);
        
        if (!$authParts) {
            return false;
        }
        
        $accessKey = $authParts['access_key'];
        $signature = $authParts['signature'];
        $signedHeaders = $authParts['signed_headers'];
        
        // Check if access key exists
        if (!isset($this->credentials['access_keys'][$accessKey])) {
            Utils::logError("Invalid access key: {$accessKey}");
            return false;
        }
        
        $secretKey = $this->credentials['access_keys'][$accessKey]['secret'];
        
        // Calculate expected signature (simplified version)
        $expectedSignature = $this->calculateSignature($secretKey, $signedHeaders);
        
        if (hash_equals($expectedSignature, $signature)) {
            $this->setCurrentUser($accessKey);
            return true;
        }
        
        Utils::logError("Signature mismatch for access key: {$accessKey}");
        return false;
    }
    
    /**
     * Authenticate using simple API key
     */
    private function authenticateWithApiKey()
    {
        $apiKey = null;
        
        // Check for API key in headers
        if (isset($_SERVER['HTTP_X_API_KEY'])) {
            $apiKey = $_SERVER['HTTP_X_API_KEY'];
        } elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $auth = $_SERVER['HTTP_AUTHORIZATION'];
            if (strpos($auth, 'Bearer ') === 0) {
                $apiKey = substr($auth, 7);
            }
        } elseif (isset($_GET['api_key'])) {
            $apiKey = $_GET['api_key'];
        }
        
        if (!$apiKey) {
            return false;
        }
        
        // Check if API key exists in credentials
        foreach ($this->credentials['access_keys'] as $accessKey => $keyData) {
            if (isset($keyData['api_key']) && hash_equals($keyData['api_key'], $apiKey)) {
                $this->setCurrentUser($accessKey);
                return true;
            }
        }
        
        Utils::logError("Invalid API key: {$apiKey}");
        return false;
    }
    
    /**
     * Authenticate using HTTP Basic Authentication
     */
    private function authenticateWithBasicAuth()
    {
        if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_PW'])) {
            return false;
        }
        
        $username = $_SERVER['PHP_AUTH_USER'];
        $password = $_SERVER['PHP_AUTH_PW'];
        
        // Check credentials
        if (isset($this->credentials['access_keys'][$username])) {
            $keyData = $this->credentials['access_keys'][$username];
            
            if (isset($keyData['password']) && hash_equals($keyData['password'], $password)) {
                $this->setCurrentUser($username);
                return true;
            }
        }
        
        Utils::logError("Invalid basic auth credentials: {$username}");
        return false;
    }
    
    /**
     * Get authorization header
     */
    private function getAuthorizationHeader()
    {
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            return $_SERVER['HTTP_AUTHORIZATION'];
        }
        
        // Check for Authorization header in different formats
        $headers = getallheaders();
        if ($headers && isset($headers['Authorization'])) {
            return $headers['Authorization'];
        }
        
        return null;
    }
    
    /**
     * Parse AWS authorization header
     */
    private function parseAuthorizationHeader($authHeader)
    {
        // Example: AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/20230101/us-east-1/s3/aws4_request, SignedHeaders=host;range;x-amz-date, Signature=signature
        
        if (!preg_match('/AWS4-HMAC-SHA256\s+Credential=([^\/]+)\/[^,]+,\s*SignedHeaders=([^,]+),\s*Signature=(.+)/', $authHeader, $matches)) {
            return false;
        }
        
        return [
            'access_key' => $matches[1],
            'signed_headers' => $matches[2],
            'signature' => $matches[3]
        ];
    }
    
    /**
     * Calculate signature (simplified version)
     */
    private function calculateSignature($secretKey, $signedHeaders)
    {
        // This is a simplified signature calculation
        // In a production environment, you should implement the full AWS Signature Version 4 algorithm
        
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = $_SERVER['REQUEST_URI'];
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $date = $_SERVER['HTTP_X_AMZ_DATE'] ?? date('Ymd\THis\Z');
        
        $stringToSign = "{$method}\n{$uri}\n{$host}\n{$date}";
        
        return hash_hmac('sha256', $stringToSign, $secretKey);
    }
    
    /**
     * Set current authenticated user
     */
    private function setCurrentUser($accessKey)
    {
        $_SESSION['authenticated_user'] = $accessKey;
        $_SESSION['auth_time'] = time();
    }
    
    /**
     * Get current authenticated user
     */
    public function getCurrentUser()
    {
        return $_SESSION['authenticated_user'] ?? null;
    }
    
    /**
     * Check if user has permission for operation
     */
    public function hasPermission($operation, $resource = null)
    {
        $user = $this->getCurrentUser();
        
        if (!$user || !isset($this->credentials['access_keys'][$user])) {
            return false;
        }
        
        $permissions = $this->credentials['access_keys'][$user]['permissions'] ?? [];
        
        // Check for specific permission
        if (in_array($operation, $permissions)) {
            return true;
        }
        
        // Check for wildcard permission
        if (in_array('*', $permissions)) {
            return true;
        }
        
        // Check for read/write permissions
        if ($operation === 'read' && in_array('read', $permissions)) {
            return true;
        }
        
        if (in_array($operation, ['write', 'put', 'post', 'delete']) && in_array('write', $permissions)) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Load credentials from configuration
     */
    private function loadCredentials()
    {
        $credentialsFile = CONFIG_PATH . '/credentials.php';
        
        if (file_exists($credentialsFile)) {
            $this->credentials = require $credentialsFile;
        } else {
            // Create default credentials file
            $this->credentials = $this->getDefaultCredentials();
            $this->saveCredentials();
        }
    }
    
    /**
     * Save credentials to file
     */
    private function saveCredentials()
    {
        $credentialsFile = CONFIG_PATH . '/credentials.php';
        $content = "<?php\n\nreturn " . var_export($this->credentials, true) . ";\n";
        
        file_put_contents($credentialsFile, $content, LOCK_EX);
        chmod($credentialsFile, 0600); // Restrict access
    }
    
    /**
     * Get default credentials
     */
    private function getDefaultCredentials()
    {
        return [
            'access_keys' => [
                'AKIAIOSFODNN7EXAMPLE' => [
                    'secret' => 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
                    'api_key' => bin2hex(random_bytes(32)),
                    'password' => 'admin123',
                    'permissions' => ['read', 'write'],
                    'created' => date('c'),
                    'active' => true
                ]
            ]
        ];
    }
    
    /**
     * Add new access key
     */
    public function addAccessKey($accessKey, $secretKey, $permissions = ['read', 'write'])
    {
        $this->credentials['access_keys'][$accessKey] = [
            'secret' => $secretKey,
            'api_key' => bin2hex(random_bytes(32)),
            'password' => bin2hex(random_bytes(16)),
            'permissions' => $permissions,
            'created' => date('c'),
            'active' => true
        ];
        
        $this->saveCredentials();
        return true;
    }
    
    /**
     * Remove access key
     */
    public function removeAccessKey($accessKey)
    {
        if (isset($this->credentials['access_keys'][$accessKey])) {
            unset($this->credentials['access_keys'][$accessKey]);
            $this->saveCredentials();
            return true;
        }
        
        return false;
    }
    
    /**
     * Update access key permissions
     */
    public function updatePermissions($accessKey, $permissions)
    {
        if (isset($this->credentials['access_keys'][$accessKey])) {
            $this->credentials['access_keys'][$accessKey]['permissions'] = $permissions;
            $this->saveCredentials();
            return true;
        }
        
        return false;
    }
    
    /**
     * Deactivate access key
     */
    public function deactivateAccessKey($accessKey)
    {
        if (isset($this->credentials['access_keys'][$accessKey])) {
            $this->credentials['access_keys'][$accessKey]['active'] = false;
            $this->saveCredentials();
            return true;
        }
        
        return false;
    }
    
    /**
     * List all access keys
     */
    public function listAccessKeys()
    {
        $keys = [];
        
        foreach ($this->credentials['access_keys'] as $accessKey => $data) {
            $keys[] = [
                'access_key' => $accessKey,
                'permissions' => $data['permissions'] ?? [],
                'created' => $data['created'] ?? 'Unknown',
                'active' => $data['active'] ?? true
            ];
        }
        
        return $keys;
    }
    
    /**
     * Validate request signature (basic implementation)
     */
    public function validateRequestSignature($accessKey, $signature, $stringToSign)
    {
        if (!isset($this->credentials['access_keys'][$accessKey])) {
            return false;
        }
        
        $secretKey = $this->credentials['access_keys'][$accessKey]['secret'];
        $expectedSignature = hash_hmac('sha256', $stringToSign, $secretKey);
        
        return hash_equals($expectedSignature, $signature);
    }
    
    /**
     * Rate limiting check
     */
    public function checkRateLimit($user = null)
    {
        if (!$user) {
            $user = $this->getCurrentUser();
        }
        
        if (!$user) {
            return true; // No rate limiting for unauthenticated requests
        }
        
        // Simple rate limiting implementation
        $rateLimitFile = LOGS_PATH . "/rate_limit_{$user}.json";
        $now = time();
        $window = 3600; // 1 hour window
        $maxRequests = 1000; // Max requests per hour
        
        $rateLimitData = [];
        if (file_exists($rateLimitFile)) {
            $rateLimitData = json_decode(file_get_contents($rateLimitFile), true) ?: [];
        }
        
        // Clean old entries
        $rateLimitData = array_filter($rateLimitData, function($timestamp) use ($now, $window) {
            return ($now - $timestamp) < $window;
        });
        
        // Check if limit exceeded
        if (count($rateLimitData) >= $maxRequests) {
            Utils::logError("Rate limit exceeded for user: {$user}");
            return false;
        }
        
        // Add current request
        $rateLimitData[] = $now;
        
        // Save rate limit data
        file_put_contents($rateLimitFile, json_encode($rateLimitData), LOCK_EX);
        
        return true;
    }
    
    /**
     * IP whitelist check
     */
    public function checkIPWhitelist()
    {
        if (!isset($this->config['ip_whitelist']) || empty($this->config['ip_whitelist'])) {
            return true; // No whitelist configured
        }
        
        $clientIP = $this->getClientIP();
        $whitelist = $this->config['ip_whitelist'];
        
        foreach ($whitelist as $allowedIP) {
            if ($this->ipMatches($clientIP, $allowedIP)) {
                return true;
            }
        }
        
        Utils::logError("IP not in whitelist: {$clientIP}");
        return false;
    }
    
    /**
     * Get client IP address
     */
    private function getClientIP()
    {
        $headers = [
            'HTTP_CF_CONNECTING_IP',     // Cloudflare
            'HTTP_CLIENT_IP',            // Proxy
            'HTTP_X_FORWARDED_FOR',      // Load balancer/proxy
            'HTTP_X_FORWARDED',          // Proxy
            'HTTP_X_CLUSTER_CLIENT_IP',  // Cluster
            'HTTP_FORWARDED_FOR',        // Proxy
            'HTTP_FORWARDED',            // Proxy
            'REMOTE_ADDR'                // Standard
        ];
        
        foreach ($headers as $header) {
            if (isset($_SERVER[$header]) && !empty($_SERVER[$header])) {
                $ips = explode(',', $_SERVER[$header]);
                return trim($ips[0]);
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
    
    /**
     * Check if IP matches pattern (supports CIDR)
     */
    private function ipMatches($ip, $pattern)
    {
        if ($ip === $pattern) {
            return true;
        }
        
        // Check CIDR notation
        if (strpos($pattern, '/') !== false) {
            list($subnet, $mask) = explode('/', $pattern);
            
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && 
                filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                
                $ipLong = ip2long($ip);
                $subnetLong = ip2long($subnet);
                $maskLong = -1 << (32 - (int)$mask);
                
                return ($ipLong & $maskLong) === ($subnetLong & $maskLong);
            }
        }
        
        return false;
    }
}

