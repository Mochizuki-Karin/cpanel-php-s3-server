<?php
/**
 * Bucket management for S3-compatible operations
 */
class BucketManager
{
    private $fileSystem;
    private $config;
    
    public function __construct($fileSystem, $config)
    {
        $this->fileSystem = $fileSystem;
        $this->config = $config;
    }
    
    /**
     * List all buckets
     */
    public function listBuckets()
    {
        return $this->fileSystem->listBuckets();
    }
    
    /**
     * Check if bucket exists
     */
    public function bucketExists($bucketName)
    {
        return $this->fileSystem->bucketExists($bucketName);
    }
    
    /**
     * Create a new bucket
     */
    public function createBucket($bucketName)
    {
        // Validate bucket name
        if (!Utils::isValidBucketName($bucketName)) {
            Utils::logError("Invalid bucket name: {$bucketName}");
            return false;
        }
        
        // Check if bucket already exists
        if ($this->bucketExists($bucketName)) {
            Utils::logError("Bucket already exists: {$bucketName}");
            return false;
        }
        
        // Check bucket limit (if configured)
        if (isset($this->config['max_buckets'])) {
            $existingBuckets = $this->listBuckets();
            if (count($existingBuckets) >= $this->config['max_buckets']) {
                Utils::logError("Maximum bucket limit reached");
                return false;
            }
        }
        
        // Create bucket directory
        if ($this->fileSystem->createBucket($bucketName)) {
            // Create bucket configuration file
            $this->createBucketConfig($bucketName);
            
            Utils::logInfo("Created bucket: {$bucketName}");
            return true;
        }
        
        Utils::logError("Failed to create bucket: {$bucketName}");
        return false;
    }
    
    /**
     * Delete a bucket
     */
    public function deleteBucket($bucketName)
    {
        if (!$this->bucketExists($bucketName)) {
            Utils::logError("Bucket does not exist: {$bucketName}");
            return false;
        }
        
        // Check if bucket is empty
        $objects = $this->fileSystem->listBucketContents($bucketName);
        if (!empty($objects)) {
            Utils::logError("Cannot delete non-empty bucket: {$bucketName}");
            return false;
        }
        
        // Delete bucket configuration
        $this->deleteBucketConfig($bucketName);
        
        // Delete bucket directory
        if ($this->fileSystem->deleteBucket($bucketName)) {
            Utils::logInfo("Deleted bucket: {$bucketName}");
            return true;
        }
        
        Utils::logError("Failed to delete bucket: {$bucketName}");
        return false;
    }
    
    /**
     * Get bucket configuration
     */
    public function getBucketConfig($bucketName)
    {
        $configPath = $this->getBucketConfigPath($bucketName);
        
        if (!file_exists($configPath)) {
            return $this->getDefaultBucketConfig();
        }
        
        $config = json_decode(file_get_contents($configPath), true);
        return $config ?: $this->getDefaultBucketConfig();
    }
    
    /**
     * Update bucket configuration
     */
    public function updateBucketConfig($bucketName, $config)
    {
        if (!$this->bucketExists($bucketName)) {
            return false;
        }
        
        $configPath = $this->getBucketConfigPath($bucketName);
        $configJson = json_encode($config, JSON_PRETTY_PRINT);
        
        return file_put_contents($configPath, $configJson, LOCK_EX) !== false;
    }
    
    /**
     * Get bucket statistics
     */
    public function getBucketStats($bucketName)
    {
        if (!$this->bucketExists($bucketName)) {
            return null;
        }
        
        $objects = $this->fileSystem->listBucketContents($bucketName);
        $totalSize = $this->fileSystem->getBucketSize($bucketName);
        
        return [
            'name' => $bucketName,
            'object_count' => count($objects),
            'total_size' => $totalSize,
            'total_size_formatted' => Utils::formatFileSize($totalSize),
            'created' => $this->getBucketCreationDate($bucketName),
            'last_modified' => $this->getBucketLastModified($bucketName)
        ];
    }
    
    /**
     * Get all bucket statistics
     */
    public function getAllBucketStats()
    {
        $buckets = $this->listBuckets();
        $stats = [];
        
        foreach ($buckets as $bucket) {
            $stats[] = $this->getBucketStats($bucket['name']);
        }
        
        return $stats;
    }
    
    /**
     * Check bucket quota (if configured)
     */
    public function checkBucketQuota($bucketName)
    {
        $config = $this->getBucketConfig($bucketName);
        
        if (!isset($config['quota']) || $config['quota'] <= 0) {
            return true; // No quota set
        }
        
        $currentSize = $this->fileSystem->getBucketSize($bucketName);
        return $currentSize < $config['quota'];
    }
    
    /**
     * Get bucket quota usage
     */
    public function getBucketQuotaUsage($bucketName)
    {
        $config = $this->getBucketConfig($bucketName);
        $currentSize = $this->fileSystem->getBucketSize($bucketName);
        
        $quota = isset($config['quota']) ? $config['quota'] : 0;
        $usage = $quota > 0 ? ($currentSize / $quota) * 100 : 0;
        
        return [
            'current_size' => $currentSize,
            'quota' => $quota,
            'usage_percent' => min(100, $usage),
            'available' => max(0, $quota - $currentSize)
        ];
    }
    
    /**
     * Create bucket configuration file
     */
    private function createBucketConfig($bucketName)
    {
        $config = $this->getDefaultBucketConfig();
        $config['created'] = Utils::getTimestamp();
        
        return $this->updateBucketConfig($bucketName, $config);
    }
    
    /**
     * Delete bucket configuration file
     */
    private function deleteBucketConfig($bucketName)
    {
        $configPath = $this->getBucketConfigPath($bucketName);
        
        if (file_exists($configPath)) {
            return unlink($configPath);
        }
        
        return true;
    }
    
    /**
     * Get bucket configuration file path
     */
    private function getBucketConfigPath($bucketName)
    {
        return $this->fileSystem->getBucketPath($bucketName) . '/.bucket-config.json';
    }
    
    /**
     * Get default bucket configuration
     */
    private function getDefaultBucketConfig()
    {
        return [
            'versioning' => false,
            'public_read' => false,
            'public_write' => false,
            'quota' => isset($this->config['default_bucket_quota']) ? $this->config['default_bucket_quota'] : 0,
            'created' => Utils::getTimestamp(),
            'region' => 'us-east-1'
        ];
    }
    
    /**
     * Get bucket creation date
     */
    private function getBucketCreationDate($bucketName)
    {
        $config = $this->getBucketConfig($bucketName);
        
        if (isset($config['created'])) {
            return $config['created'];
        }
        
        // Fallback to directory creation time
        $bucketPath = $this->fileSystem->getBucketPath($bucketName);
        if (is_dir($bucketPath)) {
            return date('c', filemtime($bucketPath));
        }
        
        return Utils::getTimestamp();
    }
    
    /**
     * Get bucket last modified date
     */
    private function getBucketLastModified($bucketName)
    {
        $bucketPath = $this->fileSystem->getBucketPath($bucketName);
        
        if (is_dir($bucketPath)) {
            return date('c', filemtime($bucketPath));
        }
        
        return Utils::getTimestamp();
    }
    
    /**
     * Validate bucket operation permissions
     */
    public function canPerformOperation($bucketName, $operation, $user = null)
    {
        $config = $this->getBucketConfig($bucketName);
        
        switch ($operation) {
            case 'read':
                return true; // Always allow read for authenticated users
                
            case 'write':
                return true; // Always allow write for authenticated users
                
            case 'delete':
                return true; // Always allow delete for authenticated users
                
            case 'public_read':
                return isset($config['public_read']) ? $config['public_read'] : false;
                
            case 'public_write':
                return isset($config['public_write']) ? $config['public_write'] : false;
                
            default:
                return false;
        }
    }
    
    /**
     * Set bucket public access
     */
    public function setBucketPublicAccess($bucketName, $read = false, $write = false)
    {
        $config = $this->getBucketConfig($bucketName);
        $config['public_read'] = $read;
        $config['public_write'] = $write;
        
        return $this->updateBucketConfig($bucketName, $config);
    }
    
    /**
     * Set bucket quota
     */
    public function setBucketQuota($bucketName, $quota)
    {
        $config = $this->getBucketConfig($bucketName);
        $config['quota'] = max(0, intval($quota));
        
        return $this->updateBucketConfig($bucketName, $config);
    }
}

