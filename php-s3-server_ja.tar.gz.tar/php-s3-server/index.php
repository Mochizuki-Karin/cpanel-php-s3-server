<?php
/**
 * PHP S3 Server - Main Entry Point
 * 
 * A lightweight S3-compatible server for cPanel free hosting
 * 
 * @author PHP S3 Server
 * @version 1.0.0
 */

// Error reporting for development (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set timezone
date_default_timezone_set('UTC');

// Define base paths
define('BASE_PATH', __DIR__);
define('SRC_PATH', BASE_PATH . '/src');
define('CONFIG_PATH', BASE_PATH . '/config');
define('STORAGE_PATH', BASE_PATH . '/storage');
define('LOGS_PATH', BASE_PATH . '/logs');

// Include required files
require_once SRC_PATH . '/Utils.php';
require_once SRC_PATH . '/Response.php';
require_once SRC_PATH . '/Auth.php';
require_once SRC_PATH . '/FileSystem.php';
require_once SRC_PATH . '/BucketManager.php';
require_once SRC_PATH . '/ObjectManager.php';
require_once SRC_PATH . '/Router.php';

// Load configuration
$config = require CONFIG_PATH . '/config.php';

// Set memory limit and execution time for file operations
ini_set('memory_limit', '128M');
ini_set('max_execution_time', 300);

// Enable CORS for all origins
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, HEAD, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Amz-Date, X-Amz-Content-Sha256, X-Amz-Target');
header('Access-Control-Expose-Headers: ETag, x-amz-request-id');

// Handle preflight OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    // Initialize components
    $response = new Response();
    $auth = new Auth($config);
    $fileSystem = new FileSystem(STORAGE_PATH);
    $bucketManager = new BucketManager($fileSystem, $config);
    $objectManager = new ObjectManager($fileSystem, $config);
    $router = new Router($response, $auth, $bucketManager, $objectManager);
    
    // Process the request
    $router->handleRequest();
    
} catch (Exception $e) {
    // Log error
    Utils::logError('Fatal error: ' . $e->getMessage());
    
    // Return error response
    $response = new Response();
    $response->sendError(500, 'InternalError', 'Internal server error occurred');
}

