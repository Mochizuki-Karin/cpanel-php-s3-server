# PHP S3 Server 安全指南

本文档详细说明了PHP S3 Server的安全特性、最佳实践和安全配置建议。

## 安全概述

PHP S3 Server采用多层安全架构，包括认证、授权、数据保护和访问控制。虽然这是一个轻量级实现，但仍然提供了企业级的安全功能。

## 认证机制

### 1. 多重认证方式

PHP S3 Server支持三种认证方式，提供灵活的安全选项：

#### API密钥认证（推荐）
- 使用自定义API密钥进行认证
- 密钥存储在服务器端，不在URL中传输
- 支持密钥轮换和撤销

```http
X-Api-Key: your-secure-api-key-here
```

#### AWS签名版本4（简化版）
- 兼容标准S3客户端工具
- 使用HMAC-SHA256签名算法
- 防止请求重放攻击

```http
Authorization: AWS4-HMAC-SHA256 Credential=ACCESS_KEY/20240101/us-east-1/s3/aws4_request, SignedHeaders=host, Signature=signature
```

#### HTTP基本认证
- 适用于简单的测试环境
- 用户名密码Base64编码
- 建议仅在HTTPS环境下使用

```http
Authorization: Basic base64(username:password)
```

### 2. 认证配置最佳实践

#### 强密码策略
```php
// 在 config/credentials.php 中
'access_keys' => [
    'AKIA...' => [
        'secret' => 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY', // 至少40个字符
        'api_key' => bin2hex(random_bytes(32)), // 64个十六进制字符
        'password' => bin2hex(random_bytes(16)), // 32个十六进制字符
        'permissions' => ['read', 'write'],
        'active' => true
    ]
]
```

#### 定期密钥轮换
- 建议每90天更换一次访问密钥
- 使用脚本自动生成强密钥
- 保留旧密钥的备份直到确认新密钥正常工作

```bash
# 生成新的API密钥
php -r "echo bin2hex(random_bytes(32)) . PHP_EOL;"

# 生成新的密钥
php -r "echo base64_encode(random_bytes(30)) . PHP_EOL;"
```

## 授权和权限控制

### 1. 基于角色的访问控制

PHP S3 Server支持细粒度的权限控制：

```php
'permissions' => [
    'read',    // 读取对象和列出存储桶
    'write',   // 创建和更新对象
    'delete',  // 删除对象和存储桶
    'admin'    // 管理权限和配置
]
```

### 2. 权限级别说明

| 权限 | 描述 | 允许的操作 |
|------|------|------------|
| read | 只读访问 | GET, HEAD, LIST |
| write | 读写访问 | read + PUT, POST |
| delete | 完全访问 | write + DELETE |
| admin | 管理权限 | delete + 用户管理 |

### 3. 存储桶级权限

```php
// 存储桶配置示例
'bucket_config' => [
    'public_read' => false,   // 公开读取
    'public_write' => false,  // 公开写入
    'owner_only' => true      // 仅所有者访问
]
```

## 数据保护

### 1. 路径遍历防护

系统自动防止路径遍历攻击：

```php
// Utils.php 中的安全检查
public static function sanitizePath($path)
{
    // 移除路径遍历尝试
    $path = str_replace(['../', '..\\', '../', '..\\'], '', $path);
    
    // 移除前导斜杠
    $path = ltrim($path, '/\\');
    
    return $path;
}
```

### 2. 文件类型验证

```php
// 允许的文件类型（可配置）
'allowed_mime_types' => [
    'text/plain',
    'image/jpeg',
    'image/png',
    'application/pdf',
    // 添加更多类型...
]
```

### 3. 文件大小限制

```php
// 在 config/config.php 中
'max_file_size' => 100 * 1024 * 1024, // 100MB
'max_total_size' => 1024 * 1024 * 1024, // 1GB总限制
```

## 网络安全

### 1. HTTPS强制

```php
// 在 config/config.php 中启用
'require_https' => true,
```

```apache
# 在 .htaccess 中强制HTTPS
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 2. CORS配置

```php
'allowed_origins' => [
    'https://yourdomain.com',
    'https://app.yourdomain.com'
], // 不要使用 ['*'] 在生产环境中
```

### 3. 安全头设置

```apache
# 在 .htaccess 中添加安全头
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"
Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
Header always set Content-Security-Policy "default-src 'self'"
```

## 访问控制

### 1. IP白名单

```php
// 在 config/config.php 中配置
'ip_whitelist' => [
    '192.168.1.0/24',    // 本地网络
    '203.0.113.0/24',    // 办公网络
    '198.51.100.50'      // 特定IP
]
```

### 2. 速率限制

```php
// 速率限制配置
'rate_limit_enabled' => true,
'rate_limit_requests' => 1000,  // 每小时请求数
'rate_limit_window' => 3600,    // 时间窗口（秒）
'rate_limit_burst' => 10        // 突发请求限制
```

### 3. 会话管理

```php
// 会话安全设置
'session_timeout' => 3600,      // 1小时
'max_failed_attempts' => 5,     // 最大失败尝试次数
'lockout_duration' => 900       // 锁定时间（15分钟）
```

## 文件系统安全

### 1. 文件权限设置

```bash
# 推荐的文件权限
chmod 755 php-s3-server/                    # 目录
chmod 644 php-s3-server/*.php               # PHP文件
chmod 600 php-s3-server/config/credentials.php  # 敏感配置
chmod 755 php-s3-server/storage/            # 存储目录
chmod 755 php-s3-server/logs/               # 日志目录
```

### 2. 目录保护

```apache
# 保护敏感目录
<Directory "/path/to/php-s3-server/config">
    Order deny,allow
    Deny from all
</Directory>

<Directory "/path/to/php-s3-server/logs">
    Order deny,allow
    Deny from all
</Directory>

<Directory "/path/to/php-s3-server/src">
    Order deny,allow
    Deny from all
</Directory>
```

### 3. 文件上传安全

```php
// 文件上传验证
public function validateUpload($filename, $content)
{
    // 检查文件扩展名
    $allowedExtensions = ['txt', 'jpg', 'png', 'pdf'];
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    if (!in_array($extension, $allowedExtensions)) {
        throw new Exception('File type not allowed');
    }
    
    // 检查文件内容
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_buffer($finfo, $content);
    finfo_close($finfo);
    
    // 验证MIME类型
    if (!in_array($mimeType, $this->allowedMimeTypes)) {
        throw new Exception('MIME type not allowed');
    }
    
    return true;
}
```

## 日志和监控

### 1. 安全日志记录

```php
// 记录安全事件
Utils::logSecurity('Failed authentication attempt', [
    'ip' => $_SERVER['REMOTE_ADDR'],
    'user_agent' => $_SERVER['HTTP_USER_AGENT'],
    'timestamp' => time()
]);
```

### 2. 异常活动检测

```php
// 检测异常活动
public function detectAnomalousActivity($userId)
{
    $recentRequests = $this->getRecentRequests($userId, 3600); // 1小时内
    
    // 检查请求频率
    if (count($recentRequests) > 1000) {
        $this->triggerSecurityAlert('High request frequency', $userId);
    }
    
    // 检查失败的认证尝试
    $failedAttempts = $this->getFailedAttempts($userId, 900); // 15分钟内
    if (count($failedAttempts) > 5) {
        $this->lockAccount($userId, 900); // 锁定15分钟
    }
}
```

### 3. 日志轮换和保护

```bash
# 设置日志轮换
# 在 crontab 中添加
0 0 * * * /path/to/rotate-logs.sh

# rotate-logs.sh 内容
#!/bin/bash
cd /path/to/php-s3-server/logs
mv s3-server.log s3-server.log.$(date +%Y%m%d)
touch s3-server.log
chmod 644 s3-server.log

# 删除30天前的日志
find . -name "s3-server.log.*" -mtime +30 -delete
```

## 备份和恢复

### 1. 配置备份

```bash
#!/bin/bash
# backup-config.sh
BACKUP_DIR="/path/to/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# 备份配置文件
tar -czf "$BACKUP_DIR/config_$DATE.tar.gz" config/

# 备份存储数据
tar -czf "$BACKUP_DIR/storage_$DATE.tar.gz" storage/

# 保留最近30天的备份
find "$BACKUP_DIR" -name "*.tar.gz" -mtime +30 -delete
```

### 2. 加密备份

```bash
# 使用GPG加密备份
gpg --cipher-algo AES256 --compress-algo 1 --s2k-mode 3 \
    --s2k-digest-algo SHA512 --s2k-count 65536 --symmetric \
    --output "backup_$DATE.tar.gz.gpg" "backup_$DATE.tar.gz"

# 删除未加密的备份
rm "backup_$DATE.tar.gz"
```

## 安全审计

### 1. 定期安全检查清单

- [ ] 检查所有访问密钥的强度
- [ ] 验证文件权限设置
- [ ] 审查用户权限分配
- [ ] 检查日志中的异常活动
- [ ] 验证HTTPS配置
- [ ] 测试备份和恢复流程
- [ ] 更新PHP和依赖项
- [ ] 检查磁盘空间使用情况

### 2. 漏洞扫描

```bash
# 使用工具扫描常见漏洞
# 示例：使用 nikto 扫描Web应用
nikto -h https://yourdomain.com/s3-server/

# 检查PHP配置
php -m | grep -E "(openssl|hash|json|xml)"
```

### 3. 渗透测试

定期进行渗透测试，包括：
- 认证绕过尝试
- 路径遍历测试
- 文件上传漏洞测试
- SQL注入测试（如果使用数据库）
- XSS测试

## 事件响应

### 1. 安全事件分类

| 级别 | 描述 | 响应时间 | 行动 |
|------|------|----------|------|
| 低 | 单次认证失败 | 24小时 | 记录日志 |
| 中 | 多次认证失败 | 1小时 | 临时锁定 |
| 高 | 可疑文件上传 | 15分钟 | 立即阻止 |
| 严重 | 系统入侵迹象 | 立即 | 关闭服务 |

### 2. 应急响应流程

```php
// 紧急关闭服务
public function emergencyShutdown($reason)
{
    // 记录关闭原因
    Utils::logSecurity('Emergency shutdown', ['reason' => $reason]);
    
    // 创建维护模式文件
    file_put_contents(BASE_PATH . '/.maintenance', time());
    
    // 发送通知
    $this->sendSecurityAlert('Service emergency shutdown', $reason);
    
    // 返回维护模式响应
    http_response_code(503);
    header('Retry-After: 3600');
    exit('Service temporarily unavailable due to security incident');
}
```

### 3. 恢复流程

1. **评估损害范围**
2. **修复安全漏洞**
3. **恢复数据（如需要）**
4. **加强监控**
5. **更新安全策略**
6. **重新启动服务**

## 合规性考虑

### 1. 数据保护法规

- **GDPR**: 实施数据最小化和用户权利
- **CCPA**: 提供数据透明度和控制
- **HIPAA**: 如处理医疗数据，需额外加密

### 2. 数据驻留

```php
// 配置数据存储位置
'data_residency' => [
    'allowed_regions' => ['us-east-1', 'eu-west-1'],
    'default_region' => 'us-east-1',
    'encryption_required' => true
]
```

### 3. 审计日志

```php
// 合规性审计日志
public function logComplianceEvent($event, $data)
{
    $logEntry = [
        'timestamp' => date('c'),
        'event' => $event,
        'user' => $this->getCurrentUser(),
        'ip' => $_SERVER['REMOTE_ADDR'],
        'data' => $data,
        'hash' => hash('sha256', json_encode($data))
    ];
    
    file_put_contents(
        LOGS_PATH . '/compliance.log',
        json_encode($logEntry) . PHP_EOL,
        FILE_APPEND | LOCK_EX
    );
}
```

## 最佳实践总结

### 1. 部署前检查

```bash
#!/bin/bash
# security-check.sh
echo "Running security checks..."

# 检查文件权限
echo "Checking file permissions..."
find . -name "*.php" -not -perm 644 -ls
find . -type d -not -perm 755 -ls

# 检查敏感文件
echo "Checking sensitive files..."
if [ -f "config/credentials.php" ]; then
    PERMS=$(stat -c %a config/credentials.php)
    if [ "$PERMS" != "600" ]; then
        echo "WARNING: credentials.php permissions should be 600"
    fi
fi

# 检查配置
echo "Checking configuration..."
grep -r "your-api-key-here" config/ && echo "WARNING: Default API keys found"
grep -r "admin123" config/ && echo "WARNING: Default passwords found"

echo "Security check completed."
```

### 2. 运行时监控

```php
// 实时安全监控
class SecurityMonitor
{
    public function monitorRequests()
    {
        // 检查请求频率
        $this->checkRequestRate();
        
        // 检查异常模式
        $this->detectAnomalies();
        
        // 检查文件完整性
        $this->verifyFileIntegrity();
    }
    
    private function checkRequestRate()
    {
        $ip = $_SERVER['REMOTE_ADDR'];
        $requests = $this->getRequestCount($ip, 60); // 1分钟内
        
        if ($requests > 100) {
            $this->blockIP($ip, 3600); // 阻止1小时
        }
    }
}
```

### 3. 定期维护任务

```bash
# 添加到 crontab
# 每日安全检查
0 2 * * * /path/to/security-check.sh

# 每周日志分析
0 3 * * 0 /path/to/analyze-logs.sh

# 每月密钥轮换提醒
0 9 1 * * /path/to/key-rotation-reminder.sh
```

通过遵循这些安全指南和最佳实践，您可以显著提高PHP S3 Server的安全性。记住，安全是一个持续的过程，需要定期审查和更新安全措施。

