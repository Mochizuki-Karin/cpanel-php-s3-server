<?php
/**
 * Authentication Credentials
 * 
 * IMPORTANT: Keep this file secure and never expose it publicly!
 * Set appropriate file permissions (600) to restrict access.
 */

return [
    'access_keys' => [
        // Default admin access key
        'AKIAIOSFODNN7EXAMPLE' => [
            'secret' => 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
            'api_key' => 'your-api-key-here-change-this',
            'password' => 'admin123', // For basic auth
            'permissions' => ['read', 'write'], // Available: read, write, delete, admin
            'created' => '2024-01-01T00:00:00Z',
            'active' => true,
            'description' => 'Default admin user'
        ],
        
        // Example read-only user
        'AKIAI44QH8DHBEXAMPLE' => [
            'secret' => 'je7MtGbClwBF/2Zp9Utk/h3yCo8nvbEXAMPLEKEY',
            'api_key' => 'readonly-api-key-change-this',
            'password' => 'readonly123',
            'permissions' => ['read'],
            'created' => '2024-01-01T00:00:00Z',
            'active' => true,
            'description' => 'Read-only user'
        ]
    ],
    
    // Global settings
    'settings' => [
        'require_authentication' => true,
        'allow_anonymous_read' => false,
        'session_timeout' => 3600, // 1 hour
        'max_failed_attempts' => 5,
        'lockout_duration' => 900 // 15 minutes
    ]
];

