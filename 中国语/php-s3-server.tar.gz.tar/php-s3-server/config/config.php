<?php
/**
 * PHP S3 Server Configuration
 * 
 * Adjust these settings according to your cPanel hosting environment
 */

return [
    // Storage settings
    'storage_path' => __DIR__ . '/../storage',
    'max_file_size' => 100 * 1024 * 1024, // 100MB (adjust based on your hosting limits)
    'max_buckets' => 50, // Maximum number of buckets
    'default_bucket_quota' => 1024 * 1024 * 1024, // 1GB per bucket (adjust as needed)
    
    // Security settings
    'public_access' => false, // Set to true to allow unauthenticated access
    'require_https' => false, // Set to true in production
    'ip_whitelist' => [], // Array of allowed IP addresses/CIDR blocks
    
    // CORS settings
    'allowed_origins' => ['*'], // Allowed origins for CORS
    'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE', 'HEAD', 'OPTIONS'],
    'allowed_headers' => ['Content-Type', 'Authorization', 'X-Amz-Date', 'X-Amz-Content-Sha256', 'X-Amz-Target'],
    
    // Performance settings
    'memory_limit' => '128M',
    'max_execution_time' => 300,
    'chunk_size' => 8192, // File streaming chunk size
    
    // Logging settings
    'debug' => false,
    'log_level' => 'info', // debug, info, warning, error
    'log_file' => 's3-server.log',
    'max_log_size' => 10 * 1024 * 1024, // 10MB
    
    // Rate limiting
    'rate_limit_enabled' => true,
    'rate_limit_requests' => 1000, // Requests per hour per user
    'rate_limit_window' => 3600, // Time window in seconds
    
    // Features
    'enable_versioning' => false, // Object versioning (not implemented yet)
    'enable_encryption' => false, // Server-side encryption (not implemented yet)
    'enable_compression' => false, // Response compression
    
    // cPanel specific optimizations
    'cpanel_mode' => true, // Enable cPanel-specific optimizations
    'use_file_locks' => true, // Use file locking for concurrent access
    'cleanup_temp_files' => true, // Automatically cleanup temporary files
    
    // Error handling
    'show_errors' => false, // Show detailed errors (disable in production)
    'error_log_file' => 'error.log',
    
    // Cache settings (for metadata)
    'enable_cache' => false, // Simple file-based caching
    'cache_ttl' => 300, // Cache TTL in seconds
    
    // Backup settings
    'enable_backup' => false, // Automatic backup (not implemented yet)
    'backup_interval' => 86400, // Backup interval in seconds (24 hours)
    
    // Monitoring
    'enable_stats' => true, // Enable statistics collection
    'stats_file' => 'stats.json',
    
    // Custom headers
    'custom_headers' => [
        'X-Powered-By' => 'PHP-S3-Server/1.0',
        'X-Content-Type-Options' => 'nosniff',
        'X-Frame-Options' => 'DENY'
    ]
];

