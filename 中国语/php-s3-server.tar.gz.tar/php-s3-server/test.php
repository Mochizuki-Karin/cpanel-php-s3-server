<?php
/**
 * PHP S3 Server Test Script
 * 
 * This script tests the basic functionality of the S3 server
 */

// Include the main components
require_once __DIR__ . '/src/Utils.php';
require_once __DIR__ . '/src/Response.php';
require_once __DIR__ . '/src/Auth.php';
require_once __DIR__ . '/src/FileSystem.php';
require_once __DIR__ . '/src/BucketManager.php';
require_once __DIR__ . '/src/ObjectManager.php';

// Define constants
define('BASE_PATH', __DIR__);
define('SRC_PATH', BASE_PATH . '/src');
define('CONFIG_PATH', BASE_PATH . '/config');
define('STORAGE_PATH', BASE_PATH . '/storage');
define('LOGS_PATH', BASE_PATH . '/logs');

echo "PHP S3 Server Test Suite\n";
echo "========================\n\n";

// Load configuration
$config = require CONFIG_PATH . '/config.php';

// Test 1: Basic component initialization
echo "Test 1: Component Initialization\n";
try {
    $fileSystem = new FileSystem(STORAGE_PATH);
    $bucketManager = new BucketManager($fileSystem, $config);
    $objectManager = new ObjectManager($fileSystem, $config);
    $auth = new Auth($config);
    echo "✓ All components initialized successfully\n\n";
} catch (Exception $e) {
    echo "✗ Component initialization failed: " . $e->getMessage() . "\n\n";
    exit(1);
}

// Test 2: Bucket operations
echo "Test 2: Bucket Operations\n";
$testBucket = 'test-bucket-' . time();

// Create bucket
if ($bucketManager->createBucket($testBucket)) {
    echo "✓ Bucket created: {$testBucket}\n";
} else {
    echo "✗ Failed to create bucket\n";
}

// Check if bucket exists
if ($bucketManager->bucketExists($testBucket)) {
    echo "✓ Bucket exists check passed\n";
} else {
    echo "✗ Bucket exists check failed\n";
}

// List buckets
$buckets = $bucketManager->listBuckets();
echo "✓ Found " . count($buckets) . " bucket(s)\n";

// Test 3: Object operations
echo "\nTest 3: Object Operations\n";
$testObject = 'test-file.txt';
$testContent = 'Hello, S3 Server! This is a test file.';

// Create a temporary file stream
$tempFile = tmpfile();
fwrite($tempFile, $testContent);
rewind($tempFile);

// Put object
if ($objectManager->putObject($testBucket, $testObject, $tempFile)) {
    echo "✓ Object uploaded: {$testObject}\n";
} else {
    echo "✗ Failed to upload object\n";
}

fclose($tempFile);

// Check if object exists
if ($objectManager->objectExists($testBucket, $testObject)) {
    echo "✓ Object exists check passed\n";
} else {
    echo "✗ Object exists check failed\n";
}

// Get object metadata
$metadata = $objectManager->getObjectMetadata($testBucket, $testObject);
if ($metadata) {
    echo "✓ Object metadata retrieved\n";
    echo "  - Size: " . $metadata['Content-Length'] . " bytes\n";
    echo "  - Type: " . $metadata['Content-Type'] . "\n";
} else {
    echo "✗ Failed to get object metadata\n";
}

// List objects
$objects = $objectManager->listObjects($testBucket);
echo "✓ Found " . count($objects) . " object(s) in bucket\n";

// Test 4: File system operations
echo "\nTest 4: File System Operations\n";
$objectPath = $fileSystem->getObjectPath($testBucket, $testObject);
if (file_exists($objectPath)) {
    echo "✓ Object file exists at: {$objectPath}\n";
    $actualContent = file_get_contents($objectPath);
    if ($actualContent === $testContent) {
        echo "✓ Object content matches\n";
    } else {
        echo "✗ Object content mismatch\n";
    }
} else {
    echo "✗ Object file not found\n";
}

// Test 5: Authentication
echo "\nTest 5: Authentication\n";
$accessKeys = $auth->listAccessKeys();
echo "✓ Found " . count($accessKeys) . " access key(s)\n";

foreach ($accessKeys as $key) {
    echo "  - Access Key: " . $key['access_key'] . "\n";
    echo "    Permissions: " . implode(', ', $key['permissions']) . "\n";
    echo "    Active: " . ($key['active'] ? 'Yes' : 'No') . "\n";
}

// Test 6: Utility functions
echo "\nTest 6: Utility Functions\n";

// Test bucket name validation
$validBucket = 'valid-bucket-name';
$invalidBucket = 'Invalid_Bucket_Name!';

if (Utils::isValidBucketName($validBucket)) {
    echo "✓ Valid bucket name accepted\n";
} else {
    echo "✗ Valid bucket name rejected\n";
}

if (!Utils::isValidBucketName($invalidBucket)) {
    echo "✓ Invalid bucket name rejected\n";
} else {
    echo "✗ Invalid bucket name accepted\n";
}

// Test object key validation
$validKey = 'folder/subfolder/file.txt';
$invalidKey = '../../../etc/passwd';

if (Utils::isValidObjectKey($validKey)) {
    echo "✓ Valid object key accepted\n";
} else {
    echo "✗ Valid object key rejected\n";
}

if (!Utils::isValidObjectKey($invalidKey)) {
    echo "✓ Invalid object key rejected\n";
} else {
    echo "✗ Invalid object key accepted\n";
}

// Test 7: Cleanup
echo "\nTest 7: Cleanup\n";

// Delete object
if ($objectManager->deleteObject($testBucket, $testObject)) {
    echo "✓ Object deleted\n";
} else {
    echo "✗ Failed to delete object\n";
}

// Delete bucket
if ($bucketManager->deleteBucket($testBucket)) {
    echo "✓ Bucket deleted\n";
} else {
    echo "✗ Failed to delete bucket\n";
}

// Test 8: Performance test
echo "\nTest 8: Performance Test\n";
$startTime = microtime(true);

// Create multiple small objects
$perfBucket = 'perf-test-' . time();
$bucketManager->createBucket($perfBucket);

for ($i = 0; $i < 10; $i++) {
    $key = "test-file-{$i}.txt";
    $content = "Test content for file {$i}";
    
    $tempFile = tmpfile();
    fwrite($tempFile, $content);
    rewind($tempFile);
    
    $objectManager->putObject($perfBucket, $key, $tempFile);
    fclose($tempFile);
}

$objects = $objectManager->listObjects($perfBucket);
$endTime = microtime(true);

echo "✓ Created and listed " . count($objects) . " objects in " . 
     round(($endTime - $startTime) * 1000, 2) . "ms\n";

// Cleanup performance test
foreach ($objects as $object) {
    $objectManager->deleteObject($perfBucket, $object['key']);
}
$bucketManager->deleteBucket($perfBucket);

echo "\nTest Summary\n";
echo "============\n";
echo "✓ All tests completed successfully!\n";
echo "✓ PHP S3 Server is ready for deployment\n\n";

echo "Next steps:\n";
echo "1. Upload the files to your cPanel hosting\n";
echo "2. Set proper file permissions (644 for files, 755 for directories)\n";
echo "3. Restrict access to config/ and logs/ directories\n";
echo "4. Update credentials in config/credentials.php\n";
echo "5. Test with S3 client tools\n\n";

echo "Example S3 client configuration:\n";
echo "Endpoint: https://yourdomain.com/path-to-s3-server/\n";
echo "Access Key: AKIAIOSFODNN7EXAMPLE\n";
echo "Secret Key: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\n";
echo "Region: us-east-1\n";

