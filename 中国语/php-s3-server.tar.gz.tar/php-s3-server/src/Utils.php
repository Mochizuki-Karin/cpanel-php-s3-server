<?php
/**
 * Utility functions for PHP S3 Server
 */
class Utils
{
    /**
     * Generate a unique request ID
     */
    public static function generateRequestId()
    {
        return strtoupper(bin2hex(random_bytes(8)));
    }
    
    /**
     * Get current timestamp in ISO 8601 format
     */
    public static function getTimestamp()
    {
        return gmdate('Y-m-d\TH:i:s\Z');
    }
    
    /**
     * Validate bucket name according to S3 rules
     */
    public static function isValidBucketName($name)
    {
        // Basic validation - S3 bucket naming rules
        if (strlen($name) < 3 || strlen($name) > 63) {
            return false;
        }
        
        // Must start and end with lowercase letter or number
        if (!preg_match('/^[a-z0-9]/', $name) || !preg_match('/[a-z0-9]$/', $name)) {
            return false;
        }
        
        // Can contain lowercase letters, numbers, hyphens, and periods
        if (!preg_match('/^[a-z0-9.-]+$/', $name)) {
            return false;
        }
        
        // Cannot contain consecutive periods or hyphens
        if (strpos($name, '..') !== false || strpos($name, '--') !== false) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate object key
     */
    public static function isValidObjectKey($key)
    {
        // Basic validation
        if (empty($key) || strlen($key) > 1024) {
            return false;
        }
        
        // Prevent path traversal
        if (strpos($key, '../') !== false || strpos($key, '..\\') !== false) {
            return false;
        }
        
        // Cannot start with /
        if (strpos($key, '/') === 0) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Sanitize file path
     */
    public static function sanitizePath($path)
    {
        // Remove any path traversal attempts
        $path = str_replace(['../', '..\\', '../', '..\\'], '', $path);
        
        // Remove leading slashes
        $path = ltrim($path, '/\\');
        
        return $path;
    }
    
    /**
     * Get MIME type from file extension
     */
    public static function getMimeType($filename)
    {
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        $mimeTypes = [
            'txt' => 'text/plain',
            'html' => 'text/html',
            'css' => 'text/css',
            'js' => 'application/javascript',
            'json' => 'application/json',
            'xml' => 'application/xml',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'pdf' => 'application/pdf',
            'zip' => 'application/zip',
            'mp4' => 'video/mp4',
            'mp3' => 'audio/mpeg',
        ];
        
        return isset($mimeTypes[$extension]) ? $mimeTypes[$extension] : 'application/octet-stream';
    }
    
    /**
     * Calculate MD5 hash of a file
     */
    public static function calculateMD5($filePath)
    {
        if (!file_exists($filePath)) {
            return false;
        }
        
        return md5_file($filePath);
    }
    
    /**
     * Calculate ETag for a file
     */
    public static function calculateETag($filePath)
    {
        $md5 = self::calculateMD5($filePath);
        return $md5 ? '"' . $md5 . '"' : null;
    }
    
    /**
     * Format file size in human readable format
     */
    public static function formatFileSize($bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= pow(1024, $pow);
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }
    
    /**
     * Log message to file
     */
    public static function log($level, $message)
    {
        $logFile = LOGS_PATH . '/s3-server.log';
        $timestamp = date('Y-m-d H:i:s');
        $logEntry = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
        
        // Create logs directory if it doesn't exist
        if (!is_dir(LOGS_PATH)) {
            mkdir(LOGS_PATH, 0755, true);
        }
        
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Log info message
     */
    public static function logInfo($message)
    {
        self::log('INFO', $message);
    }
    
    /**
     * Log error message
     */
    public static function logError($message)
    {
        self::log('ERROR', $message);
    }
    
    /**
     * Log debug message
     */
    public static function logDebug($message)
    {
        self::log('DEBUG', $message);
    }
    
    /**
     * Parse HTTP range header
     */
    public static function parseRangeHeader($rangeHeader, $fileSize)
    {
        if (!preg_match('/bytes=(\d+)-(\d*)/', $rangeHeader, $matches)) {
            return false;
        }
        
        $start = intval($matches[1]);
        $end = !empty($matches[2]) ? intval($matches[2]) : $fileSize - 1;
        
        if ($start > $end || $start >= $fileSize) {
            return false;
        }
        
        return ['start' => $start, 'end' => min($end, $fileSize - 1)];
    }
    
    /**
     * Stream file content with range support
     */
    public static function streamFile($filePath, $range = null)
    {
        $fileSize = filesize($filePath);
        $start = 0;
        $end = $fileSize - 1;
        
        if ($range) {
            $start = $range['start'];
            $end = $range['end'];
            
            header('HTTP/1.1 206 Partial Content');
            header("Content-Range: bytes {$start}-{$end}/{$fileSize}");
        }
        
        header('Content-Length: ' . ($end - $start + 1));
        header('Accept-Ranges: bytes');
        
        $handle = fopen($filePath, 'rb');
        if ($handle) {
            fseek($handle, $start);
            $remaining = $end - $start + 1;
            
            while ($remaining > 0 && !feof($handle)) {
                $chunkSize = min(8192, $remaining);
                echo fread($handle, $chunkSize);
                $remaining -= $chunkSize;
                
                if (ob_get_level()) {
                    ob_flush();
                }
                flush();
            }
            
            fclose($handle);
        }
    }
}

