<?php
/**
 * Object management for S3-compatible operations
 */
class ObjectManager
{
    private $fileSystem;
    private $config;
    
    public function __construct($fileSystem, $config)
    {
        $this->fileSystem = $fileSystem;
        $this->config = $config;
    }
    
    /**
     * List objects in a bucket
     */
    public function listObjects($bucketName, $prefix = '', $marker = '', $maxKeys = 1000)
    {
        if (!$this->fileSystem->bucketExists($bucketName)) {
            return [];
        }
        
        $objects = $this->fileSystem->listBucketContents($bucketName, $prefix, $maxKeys);
        
        // Apply marker filter (for pagination)
        if ($marker) {
            $objects = array_filter($objects, function($object) use ($marker) {
                return $object['key'] > $marker;
            });
        }
        
        return array_values($objects);
    }
    
    /**
     * Put/Upload an object
     */
    public function putObject($bucketName, $objectKey, $inputStream, $metadata = [])
    {
        // Validate inputs
        if (!Utils::isValidObjectKey($objectKey)) {
            Utils::logError("Invalid object key: {$objectKey}");
            return false;
        }
        
        if (!$this->fileSystem->bucketExists($bucketName)) {
            Utils::logError("Bucket does not exist: {$bucketName}");
            return false;
        }
        
        // Check file size limit
        if (isset($this->config['max_file_size'])) {
            $contentLength = $this->getContentLength();
            if ($contentLength > $this->config['max_file_size']) {
                Utils::logError("File size exceeds limit: {$contentLength} > {$this->config['max_file_size']}");
                return false;
            }
        }
        
        // Extract metadata from headers
        $objectMetadata = $this->extractMetadataFromHeaders();
        $objectMetadata = array_merge($objectMetadata, $metadata);
        
        // Store the object
        $result = $this->fileSystem->storeObject($bucketName, $objectKey, $inputStream, $objectMetadata);
        
        if ($result) {
            Utils::logInfo("Uploaded object: {$bucketName}/{$objectKey}");
        } else {
            Utils::logError("Failed to upload object: {$bucketName}/{$objectKey}");
        }
        
        return $result;
    }
    
    /**
     * Get object file path
     */
    public function getObjectPath($bucketName, $objectKey)
    {
        return $this->fileSystem->getObjectPath($bucketName, $objectKey);
    }
    
    /**
     * Check if object exists
     */
    public function objectExists($bucketName, $objectKey)
    {
        return $this->fileSystem->objectExists($bucketName, $objectKey);
    }
    
    /**
     * Delete an object
     */
    public function deleteObject($bucketName, $objectKey)
    {
        if (!$this->fileSystem->bucketExists($bucketName)) {
            Utils::logError("Bucket does not exist: {$bucketName}");
            return false;
        }
        
        $result = $this->fileSystem->deleteObject($bucketName, $objectKey);
        
        if ($result) {
            Utils::logInfo("Deleted object: {$bucketName}/{$objectKey}");
        }
        
        return $result;
    }
    
    /**
     * Get object metadata
     */
    public function getObjectMetadata($bucketName, $objectKey)
    {
        if (!$this->fileSystem->bucketExists($bucketName)) {
            return null;
        }
        
        return $this->fileSystem->getObjectMetadata($bucketName, $objectKey);
    }
    
    /**
     * Copy an object
     */
    public function copyObject($sourceBucket, $sourceKey, $destBucket, $destKey, $metadata = [])
    {
        // Check source object exists
        if (!$this->objectExists($sourceBucket, $sourceKey)) {
            Utils::logError("Source object does not exist: {$sourceBucket}/{$sourceKey}");
            return false;
        }
        
        // Check destination bucket exists
        if (!$this->fileSystem->bucketExists($destBucket)) {
            Utils::logError("Destination bucket does not exist: {$destBucket}");
            return false;
        }
        
        $sourcePath = $this->getObjectPath($sourceBucket, $sourceKey);
        $sourceStream = fopen($sourcePath, 'rb');
        
        if (!$sourceStream) {
            Utils::logError("Failed to open source file: {$sourcePath}");
            return false;
        }
        
        // Get source metadata and merge with new metadata
        $sourceMetadata = $this->getObjectMetadata($sourceBucket, $sourceKey);
        $newMetadata = array_merge($sourceMetadata ?: [], $metadata);
        
        $result = $this->putObject($destBucket, $destKey, $sourceStream, $newMetadata);
        
        fclose($sourceStream);
        
        if ($result) {
            Utils::logInfo("Copied object: {$sourceBucket}/{$sourceKey} -> {$destBucket}/{$destKey}");
        }
        
        return $result;
    }
    
    /**
     * Move an object
     */
    public function moveObject($sourceBucket, $sourceKey, $destBucket, $destKey, $metadata = [])
    {
        // Copy the object first
        if (!$this->copyObject($sourceBucket, $sourceKey, $destBucket, $destKey, $metadata)) {
            return false;
        }
        
        // Delete the source object
        if (!$this->deleteObject($sourceBucket, $sourceKey)) {
            // If delete fails, try to clean up the copied object
            $this->deleteObject($destBucket, $destKey);
            return false;
        }
        
        Utils::logInfo("Moved object: {$sourceBucket}/{$sourceKey} -> {$destBucket}/{$destKey}");
        return true;
    }
    
    /**
     * Get object info (extended metadata)
     */
    public function getObjectInfo($bucketName, $objectKey)
    {
        if (!$this->objectExists($bucketName, $objectKey)) {
            return null;
        }
        
        $objectPath = $this->getObjectPath($bucketName, $objectKey);
        $metadata = $this->getObjectMetadata($bucketName, $objectKey);
        
        return [
            'bucket' => $bucketName,
            'key' => $objectKey,
            'size' => filesize($objectPath),
            'size_formatted' => Utils::formatFileSize(filesize($objectPath)),
            'modified' => date('c', filemtime($objectPath)),
            'etag' => Utils::calculateETag($objectPath),
            'content_type' => $metadata['Content-Type'] ?? Utils::getMimeType($objectKey),
            'metadata' => $metadata,
            'path' => $objectPath
        ];
    }
    
    /**
     * Search objects by pattern
     */
    public function searchObjects($bucketName, $pattern, $maxResults = 100)
    {
        $allObjects = $this->listObjects($bucketName, '', '', 10000);
        $results = [];
        
        foreach ($allObjects as $object) {
            if (fnmatch($pattern, $object['key'])) {
                $results[] = $object;
                
                if (count($results) >= $maxResults) {
                    break;
                }
            }
        }
        
        return $results;
    }
    
    /**
     * Get objects by prefix (folder-like listing)
     */
    public function getObjectsByPrefix($bucketName, $prefix, $delimiter = '/', $maxKeys = 1000)
    {
        $objects = $this->listObjects($bucketName, $prefix, '', $maxKeys);
        $files = [];
        $folders = [];
        
        foreach ($objects as $object) {
            $key = $object['key'];
            
            // Remove prefix from key
            if ($prefix && strpos($key, $prefix) === 0) {
                $key = substr($key, strlen($prefix));
            }
            
            // Check if this is a "folder" (contains delimiter)
            $delimiterPos = strpos($key, $delimiter);
            
            if ($delimiterPos !== false) {
                // This is a folder
                $folderName = substr($key, 0, $delimiterPos + 1);
                if (!in_array($folderName, $folders)) {
                    $folders[] = $folderName;
                }
            } else {
                // This is a file
                $files[] = $object;
            }
        }
        
        return [
            'files' => $files,
            'folders' => $folders,
            'prefix' => $prefix,
            'delimiter' => $delimiter
        ];
    }
    
    /**
     * Extract metadata from HTTP headers
     */
    private function extractMetadataFromHeaders()
    {
        $metadata = [];
        
        // Standard headers
        if (isset($_SERVER['CONTENT_TYPE'])) {
            $metadata['Content-Type'] = $_SERVER['CONTENT_TYPE'];
        }
        
        if (isset($_SERVER['CONTENT_LENGTH'])) {
            $metadata['Content-Length'] = intval($_SERVER['CONTENT_LENGTH']);
        }
        
        // Custom metadata (x-amz-meta-*)
        foreach ($_SERVER as $key => $value) {
            if (strpos($key, 'HTTP_X_AMZ_META_') === 0) {
                $metaKey = 'x-amz-meta-' . strtolower(str_replace('HTTP_X_AMZ_META_', '', $key));
                $metadata[$metaKey] = $value;
            }
        }
        
        // Other S3 headers
        $s3Headers = [
            'HTTP_X_AMZ_STORAGE_CLASS' => 'x-amz-storage-class',
            'HTTP_X_AMZ_SERVER_SIDE_ENCRYPTION' => 'x-amz-server-side-encryption',
            'HTTP_CACHE_CONTROL' => 'Cache-Control',
            'HTTP_CONTENT_DISPOSITION' => 'Content-Disposition',
            'HTTP_CONTENT_ENCODING' => 'Content-Encoding',
            'HTTP_EXPIRES' => 'Expires'
        ];
        
        foreach ($s3Headers as $httpHeader => $s3Header) {
            if (isset($_SERVER[$httpHeader])) {
                $metadata[$s3Header] = $_SERVER[$httpHeader];
            }
        }
        
        return $metadata;
    }
    
    /**
     * Get content length from request
     */
    private function getContentLength()
    {
        if (isset($_SERVER['CONTENT_LENGTH'])) {
            return intval($_SERVER['CONTENT_LENGTH']);
        }
        
        // Try to get from HTTP headers
        if (isset($_SERVER['HTTP_CONTENT_LENGTH'])) {
            return intval($_SERVER['HTTP_CONTENT_LENGTH']);
        }
        
        return 0;
    }
    
    /**
     * Validate object key for security
     */
    private function validateObjectKey($objectKey)
    {
        // Check for path traversal
        if (strpos($objectKey, '../') !== false || strpos($objectKey, '..\\') !== false) {
            return false;
        }
        
        // Check for absolute paths
        if (strpos($objectKey, '/') === 0 || strpos($objectKey, '\\') === 0) {
            return false;
        }
        
        // Check length
        if (strlen($objectKey) > 1024) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Get total objects count in bucket
     */
    public function getObjectCount($bucketName)
    {
        if (!$this->fileSystem->bucketExists($bucketName)) {
            return 0;
        }
        
        $objects = $this->listObjects($bucketName, '', '', PHP_INT_MAX);
        return count($objects);
    }
    
    /**
     * Get bucket storage usage
     */
    public function getBucketStorageUsage($bucketName)
    {
        return $this->fileSystem->getBucketSize($bucketName);
    }
}

