<?php
/**
 * HTTP Response handler for S3 API compatibility
 */
class Response
{
    private $requestId;
    
    public function __construct()
    {
        $this->requestId = Utils::generateRequestId();
    }
    
    /**
     * Send success response
     */
    public function sendSuccess($data = null, $statusCode = 200)
    {
        http_response_code($statusCode);
        $this->setCommonHeaders();
        
        if ($data !== null) {
            if (is_array($data) || is_object($data)) {
                header('Content-Type: application/xml');
                echo $this->arrayToXml($data);
            } else {
                echo $data;
            }
        }
        
        exit;
    }
    
    /**
     * Send error response in S3 format
     */
    public function sendError($statusCode, $errorCode, $message, $resource = '')
    {
        http_response_code($statusCode);
        $this->setCommonHeaders();
        header('Content-Type: application/xml');
        
        $errorXml = $this->createErrorXml($errorCode, $message, $resource);
        echo $errorXml;
        
        Utils::logError("Error {$statusCode}: {$errorCode} - {$message}");
        exit;
    }
    
    /**
     * Send file download response
     */
    public function sendFile($filePath, $filename = null, $range = null)
    {
        if (!file_exists($filePath)) {
            $this->sendError(404, 'NoSuchKey', 'The specified key does not exist.');
            return;
        }
        
        $fileSize = filesize($filePath);
        $mimeType = Utils::getMimeType($filePath);
        $etag = Utils::calculateETag($filePath);
        
        // Set headers
        $this->setCommonHeaders();
        header('Content-Type: ' . $mimeType);
        header('Content-Length: ' . $fileSize);
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s T', filemtime($filePath)));
        
        if ($etag) {
            header('ETag: ' . $etag);
        }
        
        if ($filename) {
            header('Content-Disposition: attachment; filename="' . $filename . '"');
        }
        
        // Handle range requests
        if ($range) {
            Utils::streamFile($filePath, $range);
        } else {
            Utils::streamFile($filePath);
        }
    }
    
    /**
     * Send JSON response
     */
    public function sendJson($data, $statusCode = 200)
    {
        http_response_code($statusCode);
        $this->setCommonHeaders();
        header('Content-Type: application/json');
        
        echo json_encode($data, JSON_PRETTY_PRINT);
        exit;
    }
    
    /**
     * Set common S3 response headers
     */
    private function setCommonHeaders()
    {
        header('x-amz-request-id: ' . $this->requestId);
        header('x-amz-id-2: ' . base64_encode($this->requestId));
        header('Server: PHP-S3-Server/1.0');
        header('Date: ' . gmdate('D, d M Y H:i:s T'));
    }
    
    /**
     * Convert array to XML format
     */
    private function arrayToXml($data, $rootElement = null)
    {
        if ($rootElement === null) {
            // Determine root element based on data structure
            if (isset($data['Buckets'])) {
                $rootElement = 'ListAllMyBucketsResult';
            } elseif (isset($data['Contents']) || isset($data['Name'])) {
                $rootElement = 'ListBucketResult';
            } else {
                $rootElement = 'Result';
            }
        }
        
        $xml = new SimpleXMLElement("<?xml version='1.0' encoding='UTF-8'?><{$rootElement}></{$rootElement}>");
        $xml->addAttribute('xmlns', 'http://s3.amazonaws.com/doc/2006-03-01/');
        
        $this->arrayToXmlRecursive($data, $xml);
        
        return $xml->asXML();
    }
    
    /**
     * Recursive helper for array to XML conversion
     */
    private function arrayToXmlRecursive($array, $xml)
    {
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                if (is_numeric($key)) {
                    // Handle numeric keys (list items)
                    $key = 'Item';
                }
                $subnode = $xml->addChild($key);
                $this->arrayToXmlRecursive($value, $subnode);
            } else {
                $xml->addChild($key, htmlspecialchars($value));
            }
        }
    }
    
    /**
     * Create S3-compatible error XML
     */
    private function createErrorXml($code, $message, $resource = '')
    {
        $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><Error></Error>');
        $xml->addChild('Code', $code);
        $xml->addChild('Message', htmlspecialchars($message));
        $xml->addChild('Resource', htmlspecialchars($resource));
        $xml->addChild('RequestId', $this->requestId);
        
        return $xml->asXML();
    }
    
    /**
     * Send bucket list response
     */
    public function sendBucketList($buckets)
    {
        $data = [
            'Owner' => [
                'ID' => 'php-s3-server',
                'DisplayName' => 'PHP S3 Server'
            ],
            'Buckets' => []
        ];
        
        foreach ($buckets as $bucket) {
            $data['Buckets'][] = [
                'Name' => $bucket['name'],
                'CreationDate' => $bucket['created']
            ];
        }
        
        $this->sendSuccess($data);
    }
    
    /**
     * Send object list response
     */
    public function sendObjectList($bucketName, $objects, $prefix = '', $marker = '', $maxKeys = 1000)
    {
        $data = [
            'Name' => $bucketName,
            'Prefix' => $prefix,
            'Marker' => $marker,
            'MaxKeys' => $maxKeys,
            'IsTruncated' => 'false',
            'Contents' => []
        ];
        
        foreach ($objects as $object) {
            $data['Contents'][] = [
                'Key' => $object['key'],
                'LastModified' => $object['modified'],
                'ETag' => $object['etag'],
                'Size' => $object['size'],
                'StorageClass' => 'STANDARD',
                'Owner' => [
                    'ID' => 'php-s3-server',
                    'DisplayName' => 'PHP S3 Server'
                ]
            ];
        }
        
        $this->sendSuccess($data);
    }
    
    /**
     * Send object metadata response
     */
    public function sendObjectMetadata($metadata)
    {
        $this->setCommonHeaders();
        
        foreach ($metadata as $key => $value) {
            if (strpos($key, 'x-amz-') === 0 || in_array($key, ['Content-Type', 'Content-Length', 'Last-Modified', 'ETag'])) {
                header($key . ': ' . $value);
            }
        }
        
        http_response_code(200);
        exit;
    }
}

